import { useEffect, useState } from 'react';

// ============================================
// Data interfaces
// ============================================
export interface Certificate {
  id: number;
  title: string;
  issuer: string;
  date: string;
  description: string;
  imageUrl: string;
  color: string;
}

export interface Education {
  id: number;
  degree: string;
  school: string;
  location: string;
  date: string;
  gpa: string;
  description: string;
}

export interface Project {
  id: number;
  title: string;
  description: string;
  tech: string[];
  image: string;
  link: string;
  github: string;
}

export interface ExperienceItem {
  role: string;
  company: string;
  duration: string;
  location: string;
  bullets: string[];
}

export interface PortfolioData {
  name: string;
  initials: string;
  tagline: string;
  subtitle: string;
  status: string;
  location: string;
  locationShort: string;
  email: string;
  linkedin: string;
  aboutHeading: string;
  aboutP1: string;
  aboutP2: string;
  aboutP3: string;
  testimonial: string;
  testimonialAuthor: string;
  testimonialRole: string;
  certificates: Certificate[];
  education: Education[];
  projects: Project[];
  experience: ExperienceItem[];
  skills: string[];
}

// ============================================
// Default data
// ============================================
export const defaultData: PortfolioData = {
  name: "Ankit Pradhan",
  initials: "AP",
  tagline: "ANKIT PRADHAN",
  subtitle: "Electrical Engineering Student",
  status: "#OPEN TO WORK • ON-SITE & HYBRID",
  location: "Rengali, Odisha, India",
  locationShort: "RENGALI, ODISHA • INDIA",
  email: "pradhanankit283@gmail.com",
  linkedin:
    "https://www.linkedin.com/in/ankit-pradhan-b16b10285/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3Brc3QEBFlSceEobFJSc9RoA%3D%3D",
  aboutHeading: "A little\nabout me.",
  aboutP1:
    "Hi, I'm Ankit. An Electrical Engineering student passionate about embedded systems, IoT, smart automation and real-world hardware projects.",
  aboutP2:
    "I study at the Synergy Institute of Engineering and Technology in Banamaliprasad, Dhenkanal, Odisha. My projects focus on practical, real-life electronics problems—automated irrigation, smart homes and energy-efficient street lighting—always with a focus on usability, reliability and power efficiency.",
  aboutP3:
    "I'm actively looking for internships, in-plant training (IPT) and entry-level opportunities in Electrical, Electronics and IoT domains—on-site or hybrid. Outside of academics I like experimenting with sensors, reading technical blogs and working on new prototype ideas.",
  testimonial:
    "Ankit has a natural ability to turn complex electrical problems into elegant, working prototypes that are actually useful in real life.",
  testimonialAuthor: "HOD / Dept. Review",
  testimonialRole: "Electrical Engineering, Synergy Institute",
  certificates: [
    {
      id: 1,
      title: "Introduction to Microsoft Excel",
      issuer: "Coursera",
      date: "Nov 4, 2025",
      description:
        "Completed an online project on Coursera covering the basics of Microsoft Excel, including spreadsheets, formulas, charts and data organization for everyday tasks.",
      imageUrl:
        "https://images.pexels.com/photos/3990446/pexels-photo-3990446.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      color: "from-emerald-500 to-teal-500",
    },
    {
      id: 2,
      title: "Getting Started with Microsoft PowerPoint",
      issuer: "Coursera",
      date: "Nov 4, 2025",
      description:
        "Completed a project-based Coursera course on designing effective presentations using Microsoft PowerPoint, with a focus on clean layouts and storytelling.",
      imageUrl:
        "https://images.pexels.com/photos/6787046/pexels-photo-6787046.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      color: "from-orange-500 to-rose-500",
    },
    {
      id: 3,
      title: "Python for Data Science, AI & Development",
      issuer: "IBM (via Coursera)",
      date: "Nov 27, 2024",
      description:
        "Completed an IBM-authorized course covering Python fundamentals, data structures, working with APIs, and an introduction to data science and AI development.",
      imageUrl:
        "https://images.pexels.com/photos/35916546/pexels-photo-35916546.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      color: "from-blue-500 to-cyan-500",
    },
    {
      id: 4,
      title: "Excel Basics for Data Analysis",
      issuer: "IBM (via Coursera)",
      date: "Nov 27, 2024",
      description:
        "Completed an IBM-authorized course on Excel for data analysis — covering formulas, pivot tables, charts and basic data-cleaning techniques.",
      imageUrl:
        "https://images.pexels.com/photos/16846528/pexels-photo-16846528.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      color: "from-indigo-500 to-violet-500",
    },
    {
      id: 5,
      title: "PLC (Programmable Logic Controllers)",
      issuer: "CTTC, Bhubaneswar",
      date: "2024",
      description:
        "Industrial training on PLC architecture, ladder logic, I/O interfacing and basic automation project design at the Central Tool Room & Training Centre, Bhubaneswar.",
      imageUrl:
        "https://images.pexels.com/photos/18471441/pexels-photo-18471441.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      color: "from-amber-500 to-yellow-500",
    },
    {
      id: 6,
      title: "AI & Machine Learning",
      issuer: "CTTC, Bhubaneswar",
      date: "2024",
      description:
        "Training program at CTTC Bhubaneswar covering the foundations of AI & ML — including supervised/unsupervised learning, model building and real-world use cases.",
      imageUrl:
        "https://images.pexels.com/photos/6476783/pexels-photo-6476783.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      color: "from-pink-500 to-fuchsia-500",
    },
  ],
  education: [
    {
      id: 1,
      degree: "B.Tech. Electrical Engineering",
      school: "Synergy Institute of Engineering and Technology",
      location: "Banamaliprasad, Dhenkanal, Odisha, India",
      date: "Current",
      gpa: "Pursuing",
      description:
        "Core coursework in Power Systems, Control Engineering, Embedded Systems, IoT and Renewable Energy. Hands-on experience designing and prototyping electronic circuits, microcontroller-based systems and smart IoT applications.",
    },
    {
      id: 2,
      degree: "+2 Science (PCM)",
      school: "KIIT Higher Secondary School, Patia",
      location: "Bhubaneswar, Odisha, India",
      date: "2021 - 2023",
      gpa: "78%",
      description:
        "Completed higher secondary in the Science stream (Physics, Chemistry, Mathematics) under the Council of Higher Secondary Education (CHSE), Odisha. Built a strong foundation in mathematics, physics and programming fundamentals.",
    },
    {
      id: 3,
      degree: "Class 10 (CBSE)",
      school: "Odisha Adarsha Vidyalaya, Pallahara",
      location: "Pallahara, Odisha, India",
      date: "2021",
      gpa: "74%",
      description:
        "Completed secondary education under the Central Board of Secondary Education (CBSE). Active in school events, science fairs and practical workshops throughout.",
    },
  ],
  projects: [
    {
      id: 1,
      title: "Smart Plant Monitoring & Irrigation System",
      description:
        "IoT-based system designed to continuously monitor soil moisture, temperature and humidity levels, and automatically trigger water irrigation when needed. Built around Arduino/ESP32 with sensor integration and a simple web dashboard for live status tracking.",
      tech: [
        "Arduino / ESP32",
        "Sensors (Moisture, DHT)",
        "Relay Module",
        "IoT Dashboard",
        "C / Embedded",
      ],
      image:
        "https://images.pexels.com/photos/31231189/pexels-photo-31231189.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      link: "#",
      github: "#",
    },
    {
      id: 2,
      title: "Smart Home Automation System",
      description:
        "Prototype home automation system enabling remote and automated control of home appliances such as lights, fans and sockets. Includes PIR motion-based lighting, voice control and a mobile-friendly control dashboard running on a local network.",
      tech: [
        "ESP8266 / NodeMCU",
        "Relay Modules",
        "PIR Sensors",
        "WiFi",
        "Blynk / Custom Dashboard",
      ],
      image:
        "https://images.pexels.com/photos/1472443/pexels-photo-1472443.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      link: "#",
      github: "#",
    },
    {
      id: 3,
      title: "Automatic Street Light Design",
      description:
        "Energy-efficient street lighting design that turns lights on/off automatically based on ambient light intensity (LDR sensor) and vehicle/motion detection. Optimized to save power while ensuring consistent brightness where and when needed.",
      tech: [
        "LDR Sensor",
        "IR Sensors",
        "555 Timer / Microcontroller",
        "LED Arrays",
        "Solar-Ready",
      ],
      image:
        "https://images.pexels.com/photos/9799703/pexels-photo-9799703.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      link: "#",
      github: "#",
    },
  ],
  experience: [
    {
      role: "IoT & Embedded Systems Intern (Open)",
      company: "Cofix Infotech Pvt Ltd",
      duration: "Present",
      location: "Rengali, Odisha",
      bullets: [
        "Designing circuit layouts and PCB prototypes for small IoT devices",
        "Programming microcontrollers (Arduino, ESP32, NodeMCU) with real sensors",
        "Integrating hardware with web dashboards to expose live data to users",
      ],
    },
    {
      role: "B.Tech. Electrical Engineering Student",
      company: "Synergy Institute of Engineering and Technology",
      duration: "Current",
      location: "Banamaliprasad, Dhenkanal, Odisha",
      bullets: [
        "Core coursework: Power Systems, Control Engineering, Embedded Systems, IoT, Renewable Energy",
        "Designing and testing electronic circuits in lab using oscilloscopes, signal generators and simulation tools",
        "Building three significant end-to-end hardware projects focused on automation and efficiency",
      ],
    },
  ],
  skills: [
    "Arduino",
    "ESP32 / NodeMCU",
    "Sensors & Actuators",
    "Circuit Design",
    "PCB Design",
    "C / Embedded C",
    "IoT Protocols",
    "Motor & Relay Control",
    "Power Electronics",
    "MATLAB",
    "Python (Scripting)",
    "Solar & Renewable",
    "AutoCAD",
    "Proteus / Multisim",
  ],
};

// ============================================
// Persistent store hook
// ============================================
const STORAGE_KEY = "ankit-portfolio-data-v1";

export function loadData(): PortfolioData {
  if (typeof window === "undefined") return defaultData;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultData;
    const parsed = JSON.parse(raw);
    // Shallow-merge with defaults so new fields don't break older saves
    return { ...defaultData, ...parsed };
  } catch {
    return defaultData;
  }
}

export function saveData(data: PortfolioData) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.error("Failed to save portfolio data:", e);
  }
}

export function clearData() {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* noop */
  }
}

export function usePortfolioData() {
  const [data, setData] = useState<PortfolioData>(() => loadData());
  const [editMode, setEditMode] = useState(false);

  useEffect(() => {
    saveData(data);
  }, [data]);

  const update = <K extends keyof PortfolioData>(key: K, value: PortfolioData[K]) => {
    setData((prev) => ({ ...prev, [key]: value }));
  };

  const reset = () => {
    clearData();
    setData(defaultData);
  };

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "portfolio-data.json";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const importJson = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const parsed = JSON.parse(e.target?.result as string);
        setData({ ...defaultData, ...parsed });
        alert("Data imported successfully!");
      } catch {
        alert("Invalid JSON file. Please try again.");
      }
    };
    reader.readAsText(file);
  };

  return {
    data,
    setData,
    update,
    editMode,
    setEditMode,
    reset,
    exportJson,
    importJson,
  };
}
